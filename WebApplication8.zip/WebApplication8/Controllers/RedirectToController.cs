﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication8.Controllers
{
    public class RedirectToController : Controller
    {
        // GET: RedirectTo
        public ActionResult redirect()
        {
            return View();
        }
    }
}